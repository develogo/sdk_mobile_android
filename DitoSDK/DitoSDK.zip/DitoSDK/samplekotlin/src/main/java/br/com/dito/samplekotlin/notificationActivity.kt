package br.com.dito.samplekotlin

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class notificationActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notification3)
    }
}
